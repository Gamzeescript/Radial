package com.l.primero.control;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MensajeVista {
	
	@RequestMapping(value = "/mostrar", method = RequestMethod.GET)
	public ModelAndView mostrarMensaje() {
		String mensaje = "HOLA SPRING";
		ModelAndView mv = new ModelAndView();
		
		mv.addObject("mensaje",mensaje);
		mv.setViewName("index");
		return mv;
	}
}
